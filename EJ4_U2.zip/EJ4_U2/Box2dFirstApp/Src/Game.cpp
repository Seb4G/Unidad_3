#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Cuadrado Controlado por Input");
    Event evt;
    b2Vec2 gravity(0.0f, 0.0f);
    b2World world(gravity);
    b2BodyDef piso;
    b2Body* pisoBody = world.CreateBody(&piso);
    b2PolygonShape pisoShape;

    pisoShape.SetAsBox(800.0f / 30.0f, 1.0f / 30.0f, b2Vec2(400.0f / 30.0f, 0.0f), 0.0f);
    pisoBody->CreateFixture(&pisoShape, 0.0f);
    pisoShape.SetAsBox(800.0f / 30.0f, 1.0f / 30.0f, b2Vec2(400.0f / 30.0f, 600.0f / 30.0f), 0.0f);
    pisoBody->CreateFixture(&pisoShape, 0.0f);
    pisoShape.SetAsBox(1.0f / 30.0f, 600.0f / 30.0f, b2Vec2(0.0f, 300.0f / 30.0f), 0.0f);
    pisoBody->CreateFixture(&pisoShape, 0.0f);
    pisoShape.SetAsBox(1.0f / 30.0f, 600.0f / 30.0f, b2Vec2(800.0f / 30.0f, 300.0f / 30.0f), 0.0f);
    pisoBody->CreateFixture(&pisoShape, 0.0f);

    b2BodyDef cuadradoBodyDef;
    cuadradoBodyDef.type = b2_dynamicBody;
    cuadradoBodyDef.position.Set(10.0f, 10.0f);
    b2Body* cuadradoBody = world.CreateBody(&cuadradoBodyDef);
    b2PolygonShape cuadradoShape;
    cuadradoShape.SetAsBox(1.0f, 1.0f, b2Vec2(0.0f, 0.0f), 0.0f);
    b2FixtureDef cuadradoFixtureDef;
    cuadradoFixtureDef.shape = &cuadradoShape;
    cuadradoFixtureDef.density = 5.0f;
    cuadradoFixtureDef.friction = 0.3f;
    cuadradoFixtureDef.restitution = 0.5f;
    cuadradoBody->CreateFixture(&cuadradoFixtureDef);
    RectangleShape cuadrado(Vector2f(2.0f * 30.0f, 2.0f * 30.0f));
    cuadrado.setFillColor(Color::Green);
    cuadrado.setOrigin(1.0f * 30.0f, 1.0f * 30.0f);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        b2Vec2 fuerza(0.0f, 0.0f);
        if (Keyboard::isKeyPressed(Keyboard::Up))
            fuerza += b2Vec2(0.0f, -1.0f);
        if (Keyboard::isKeyPressed(Keyboard::Down))
            fuerza += b2Vec2(0.0f, 1.0f);
        if (Keyboard::isKeyPressed(Keyboard::Left))
            fuerza += b2Vec2(-1.0f, 0.0f);
        if (Keyboard::isKeyPressed(Keyboard::Right))
            fuerza += b2Vec2(1.0f, 0.0f);
        b2Vec2 cuadradoPosicion = cuadradoBody->GetPosition();
        cuadradoBody->ApplyForceToCenter(fuerza, true);

        world.Step(1/60.0f, 10, 10);
        cuadradoPosicion = cuadradoBody->GetPosition();
        cuadrado.setPosition(cuadradoPosicion.x * 30.0f, cuadradoPosicion.y * 30.0f);
        App.clear();
        App.draw(cuadrado);
        App.display();
    }

    return 0;
}