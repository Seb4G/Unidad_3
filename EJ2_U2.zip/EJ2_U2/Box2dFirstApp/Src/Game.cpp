#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Dos Pelotas con Resorte");
    b2Vec2 gravity(0.0f, 0.5f);
    b2World world(gravity);
    Event evt;
    b2BodyDef bodyDefPiso;
    bodyDefPiso.position.Set(400, 500);
    b2Body* bodyPiso = world.CreateBody(&bodyDefPiso);
    b2PolygonShape boxPiso;
    boxPiso.SetAsBox(500, 10);
    bodyPiso->CreateFixture(&boxPiso, 0.0f);

    b2BodyDef pelota1BodyDef;
    pelota1BodyDef.type = b2_dynamicBody;
    pelota1BodyDef.position.Set(4.0f, 3.0f);
    b2Body* pelota1Body = world.CreateBody(&pelota1BodyDef);
    b2CircleShape pelota1Shape;
    pelota1Shape.m_radius = 0.5f;
    b2FixtureDef pelota1FixtureDef;
    pelota1FixtureDef.shape = &pelota1Shape;
    pelota1FixtureDef.density = 1.0f;
    pelota1FixtureDef.friction = 0.3f;
    pelota1FixtureDef.restitution = 0.5f;
    pelota1Body->CreateFixture(&pelota1FixtureDef);

    b2BodyDef pelota2BodyDef;
    pelota2BodyDef.type = b2_dynamicBody;
    pelota2BodyDef.position.Set(80.0f, 3.0f);
    b2Body* pelota2Body = world.CreateBody(&pelota2BodyDef);
    b2CircleShape pelota2Shape;
    pelota2Shape.m_radius = 0.5f;
    b2FixtureDef pelota2FixtureDef;
    pelota2FixtureDef.shape = &pelota2Shape;
    pelota2FixtureDef.density = 1.0f;
    pelota2FixtureDef.friction = 0.3f;
    pelota2FixtureDef.restitution = 0.5f;
    pelota2Body->CreateFixture(&pelota2FixtureDef);

    b2DistanceJointDef jointDef;
    jointDef.Initialize(pelota1Body, pelota2Body, pelota1Body->GetWorldCenter(), pelota2Body->GetWorldCenter());
    jointDef.length = 1.0f;
    b2DistanceJoint* distJoint = (b2DistanceJoint*)world.CreateJoint(&jointDef);

    CircleShape pelota1(15.0f);
    pelota1.setFillColor(Color::Red);
    CircleShape pelota2(15.0f);
    pelota2.setFillColor(Color::Blue);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
            if (evt.type == Event::MouseButtonPressed) {
                Vector2i mousePosition = Mouse::getPosition(App);
                b2Vec2 ball2Position = pelota2Body->GetPosition();
                if (b2DistanceSquared(b2Vec2(mousePosition.x, mousePosition.y), ball2Position) < 0.5f) {
                    pelota2Body->SetType(b2_dynamicBody);
                }
            }
            if (evt.type == Event::MouseButtonReleased) {
                pelota2Body->SetType(b2_staticBody);
            }
        }
        world.Step(1 / 60.0f, 10, 10);
        if (Mouse::isButtonPressed(Mouse::Left)) {
            Vector2i mousePosition = Mouse::getPosition(App);
            pelota2Body->SetTransform(b2Vec2(mousePosition.x, mousePosition.y), 0);
        }
        App.clear();

        RectangleShape pisoShape(Vector2f(800, 20));
        pisoShape.setFillColor(Color::Green);
        pisoShape.setPosition(0, 520);
        App.draw(pisoShape);
        b2Vec2 pelotaPosition = pelota1Body->GetPosition();
        pelota1.setPosition(pelotaPosition.x, pelotaPosition.y);
        b2Vec2 pelota2Position = pelota2Body->GetPosition();
        pelota2.setPosition(pelota2Position.x, pelota2Position.y);
        App.draw(pelota1);
        App.draw(pelota2);
        App.display();
    }
    return 0;
}