#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Pelota Azul Fijada");
    b2Vec2 gravity(0.0f, 0.1f);
    b2World world(gravity);
    Event evt;
    b2BodyDef objetoBodyDef;
    objetoBodyDef.position.Set(10.0f, 10.0f);
    b2Body* objetoBody = world.CreateBody(&objetoBodyDef);
    b2PolygonShape objetoShape;
    objetoShape.SetAsBox(5.0f, 5.0f);
    b2FixtureDef objetoFixtureDef;
    objetoFixtureDef.shape = &objetoShape;
    objetoFixtureDef.density = 1.0f;
    objetoBody->CreateFixture(&objetoFixtureDef);
    RectangleShape objeto(Vector2f(100, 100));
    objeto.setFillColor(Color::Green);
    objeto.setOrigin(150, 150);

    b2BodyDef pelotaBodyDef;
    pelotaBodyDef.type = b2_dynamicBody;
    pelotaBodyDef.position.Set(15.0f, 15.0f);
    b2Body* pelotaBody = world.CreateBody(&pelotaBodyDef);
    b2CircleShape pelotaShape;
    pelotaShape.m_radius = 0.5f;
    b2FixtureDef pelotaFixtureDef;
    pelotaFixtureDef.shape = &pelotaShape;
    pelotaFixtureDef.density = 10.0f;
    pelotaFixtureDef.friction = 0.1f;
    pelotaFixtureDef.restitution = 0.1f;
    pelotaBody->CreateFixture(&pelotaFixtureDef);
    CircleShape pelota(15.0f);
    pelota.setFillColor(Color::Blue);
    pelota.setOrigin(15, 15); 

    b2DistanceJointDef jointDef;
    jointDef.Initialize(objetoBody, pelotaBody, objetoBody->GetWorldCenter(), pelotaBody->GetWorldCenter());
    jointDef.length = 5.0f;
    b2DistanceJoint* distJoint = (b2DistanceJoint*)world.CreateJoint(&jointDef);
    VertexArray resorte(Lines, 2);
    resorte[0].color = Color::Red;
    resorte[1].color = Color::Red;

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1 / 60.0f, 10, 10);
        b2Vec2 ballPosition = pelotaBody->GetPosition();
        pelota.setPosition(ballPosition.x * 30, ballPosition.y * 30);
        b2Vec2 anchor1 = distJoint->GetAnchorA();
        b2Vec2 anchor2 = distJoint->GetAnchorB();
        resorte[0].position = Vector2f(anchor1.x * 30, anchor1.y * 30);
        resorte[1].position = Vector2f(anchor2.x * 30, anchor2.y * 30);

        App.clear();
        objeto.setPosition(395, 350);
        App.draw(objeto);
        App.draw(resorte);
        App.draw(pelota);
        App.display();
    }
    return 0;
}