#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600), "Ragdoll");
    Event evt;
    b2Vec2 gravity(0.0f, 5.0f);
    b2World world(gravity);
    b2BodyDef groundBodyDef;
    groundBodyDef.position.Set(400.0f, 600.0f);
    b2Body* groundBody = world.CreateBody(&groundBodyDef);
    b2PolygonShape groundBox;
    groundBox.SetAsBox(400.0f, 10.0f);
    groundBody->CreateFixture(&groundBox, 0.0f);

    b2BodyDef torsoBodyDef;
    torsoBodyDef.type = b2_dynamicBody;
    torsoBodyDef.position.Set(400.0f, 300.0f);
    b2Body* torsoBody = world.CreateBody(&torsoBodyDef);
    b2PolygonShape torsoShape;
    torsoShape.SetAsBox(30.0f, 50.0f);
    b2FixtureDef torsoFixtureDef;
    torsoFixtureDef.shape = &torsoShape;
    torsoFixtureDef.density = 3.0f;
    torsoFixtureDef.friction = 0.5f;
    torsoBody->CreateFixture(&torsoFixtureDef);

    b2BodyDef cabezaBodyDef;
    cabezaBodyDef.type = b2_dynamicBody;
    cabezaBodyDef.position.Set(400.0f, 225.0f);
    b2Body* cabezaBody = world.CreateBody(&cabezaBodyDef);
    b2PolygonShape cabezaShape;
    cabezaShape.SetAsBox(20.0f, 20.0f);
    b2FixtureDef cabezaFixtureDef;
    cabezaFixtureDef.shape = &cabezaShape;
    cabezaFixtureDef.density = 0.5f;
    cabezaBody->CreateFixture(&cabezaFixtureDef);
    b2RevoluteJointDef cuelloJointDef;
    cuelloJointDef.Initialize(torsoBody, cabezaBody, b2Vec2(400.0f, 255.0f));
    cuelloJointDef.collideConnected = false;
    world.CreateJoint(&cuelloJointDef);

    b2BodyDef brazoIzqBodyDef;
    brazoIzqBodyDef.type = b2_dynamicBody;
    brazoIzqBodyDef.position.Set(355.0f, 300.0f);
    b2Body* brazoIzqBody = world.CreateBody(&brazoIzqBodyDef);
    b2PolygonShape brazoIzqShape;
    brazoIzqShape.SetAsBox(10.0f, 90.0f);
    b2FixtureDef brazoIzqFixtureDef;
    brazoIzqFixtureDef.shape = &brazoIzqShape;
    brazoIzqFixtureDef.density = 0.5f;
    brazoIzqBody->CreateFixture(&brazoIzqFixtureDef);
    b2RevoluteJointDef JointIzqDef;
    JointIzqDef.Initialize(torsoBody, brazoIzqBody, b2Vec2(370.0f, 280.0f));
    JointIzqDef.collideConnected = false;
    world.CreateJoint(&JointIzqDef);

    b2BodyDef brazoDerBodyDef;
    brazoDerBodyDef.type = b2_dynamicBody;
    brazoDerBodyDef.position.Set(445.0f, 300.0f);
    b2Body* brazoDerBody = world.CreateBody(&brazoDerBodyDef);
    b2PolygonShape brazoDerShape;
    brazoDerShape.SetAsBox(10.0f, 90.0f);
    b2FixtureDef brazoDerFixtureDef;
    brazoDerFixtureDef.shape = &brazoDerShape;
    brazoDerFixtureDef.density = 0.5f;
    brazoDerBody->CreateFixture(&brazoDerFixtureDef);
    b2RevoluteJointDef JointDerDef;
    JointDerDef.Initialize(torsoBody, brazoDerBody, b2Vec2(430.0f, 280.0f));
    JointDerDef.collideConnected = false;
    world.CreateJoint(&JointDerDef);

    b2BodyDef piernaIzqBodyDef;
    piernaIzqBodyDef.type = b2_dynamicBody;
    piernaIzqBodyDef.position.Set(370.0f, 390.0f);
    b2Body* piernaIzqBody = world.CreateBody(&piernaIzqBodyDef);
    b2PolygonShape piernaIzqShape;
    piernaIzqShape.SetAsBox(10.0f, 40.0f);
    b2FixtureDef piernaIzqFixtureDef;
    piernaIzqFixtureDef.shape = &piernaIzqShape;
    piernaIzqFixtureDef.density = 2.5f;
    piernaIzqBody->CreateFixture(&piernaIzqFixtureDef);
    b2RevoluteJointDef piernaIzqJointDef;
    piernaIzqJointDef.Initialize(torsoBody, piernaIzqBody, b2Vec2(385.0f, 340.0f));
    piernaIzqJointDef.collideConnected = false;
    world.CreateJoint(&piernaIzqJointDef);

    b2BodyDef piernaDerBodyDef;
    piernaDerBodyDef.type = b2_dynamicBody;
    piernaDerBodyDef.position.Set(430.0f, 390.0f);
    b2Body* piernaDerBody = world.CreateBody(&piernaDerBodyDef);
    b2PolygonShape piernaDerShape;
    piernaDerShape.SetAsBox(10.0f, 40.0f);
    b2FixtureDef piernaDerFixtureDef;
    piernaDerFixtureDef.shape = &piernaDerShape;
    piernaDerFixtureDef.density = 2.5f;
    piernaDerBody->CreateFixture(&piernaDerFixtureDef);
    b2RevoluteJointDef piernaDerJointDef;
    piernaDerJointDef.Initialize(torsoBody, piernaDerBody, b2Vec2(415.0f, 340.0f));
    piernaDerJointDef.collideConnected = false;
    world.CreateJoint(&piernaDerJointDef);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1/60.0f, 8, 3);
        App.clear();
        RectangleShape pisoShape(Vector2f(800, 20));
        pisoShape.setPosition(0, 580);
        App.draw(pisoShape);

        RectangleShape ragdoll[6];
        b2Body* partes[6] = { torsoBody, cabezaBody, brazoIzqBody, brazoDerBody, piernaIzqBody, piernaDerBody };
        Color colores[6] = { Color::Blue, Color::Green, Color::Green, Color::Green, Color::Green, Color::Green };
        Vector2f tama�os[6] = { Vector2f(60, 100), Vector2f(40, 40), Vector2f(20, 80), Vector2f(20, 80), Vector2f(20, 80), Vector2f(20, 80) };
        for (int i = 0; i < 6; ++i) {
            ragdoll[i].setSize(tama�os[i]);
            ragdoll[i].setOrigin(tama�os[i].x / 2, tama�os[i].y / 2);
            ragdoll[i].setPosition(partes[i]->GetPosition().x, partes[i]->GetPosition().y);
            ragdoll[i].setRotation(partes[i]->GetAngle() * 180 / b2_pi);
            ragdoll[i].setFillColor(colores[i]);
            App.draw(ragdoll[i]);
        }
        App.display();
    }
    return 0;
}