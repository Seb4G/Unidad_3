#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

using namespace sf;

const float constante = 20.0f;
const float posEquilibrio = 0.5f;
const float maxVelocidad = 100.0f;

int main() {
    RenderWindow App(VideoMode(800, 600), "Pelota Rebotando");
    Event evt;
    b2Vec2 gravedad(0.5f, 5.0f);
    b2World world(gravedad);
    b2BodyDef defPelota;
    defPelota.type = b2_dynamicBody;
    defPelota.position.Set(4.0f, 1.0f);
    b2Body* bodyPelota = world.CreateBody(&defPelota);
    b2CircleShape shapePelota;
    shapePelota.m_radius = 0.5f;
    b2FixtureDef fixtureDefPelota;
    fixtureDefPelota.shape = &shapePelota;
    fixtureDefPelota.density = 1.0f;
    fixtureDefPelota.friction = 0.5;
    fixtureDefPelota.restitution = 2.0f;
    bodyPelota->CreateFixture(&fixtureDefPelota);

    b2Vec2 velocidadInicial(3.0f, 1.0f);
    bodyPelota->SetLinearVelocity(velocidadInicial);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
        }
        world.Step(1/60.0f, 10, 10);
        b2Vec2 velocidad = bodyPelota->GetLinearVelocity();
        if (velocidad.Length() > maxVelocidad) {
            velocidad *= maxVelocidad;
            bodyPelota->SetLinearVelocity(velocidad);
        }

        b2Vec2 posicion = bodyPelota->GetPosition();
        b2Vec2 force(0.0f, 0.0f);
        if (posicion.x <= 0) {
            force.x = constante * (0 - posicion.x - posEquilibrio);
        }
        else if (posicion.x >= 800) {
            force.x = -constante * (posicion.x - 800 - posEquilibrio);
        }
        if (posicion.y <= 0) {
            force.y = constante * (0 - posicion.y - posEquilibrio);
        }
        else if (posicion.y >= 600) {
            force.y = -constante * (posicion.y - 600 - posEquilibrio);
        }
        bodyPelota->ApplyForceToCenter(force, true);
        App.clear();

        CircleShape pelota(25, 25);
        pelota.setFillColor(Color::Red);
        pelota.setPosition(posicion.x, posicion.y);
        pelota.setOrigin(pelota.getRadius(), pelota.getRadius());
        App.draw(pelota);
        App.display();
    }
    return 0;
}